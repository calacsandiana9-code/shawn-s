# For You — A Silent Voice-inspired gift website

Open `index.html` in a browser to preview it.

To personalize it:
- Replace the letter text.
- Change the memory cards.
- Change the timeline entries.
- Edit the final surprise message in the modal.
- You can add your own photos later.

For a public link, upload the folder to a static hosting service such as GitHub Pages or Netlify.
